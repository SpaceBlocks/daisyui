import{a as t}from"../chunks/entry.Baw_8Hlz.js";export{t as start};
