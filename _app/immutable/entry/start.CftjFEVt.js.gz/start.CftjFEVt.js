import{a as t}from"../chunks/entry.D65As2TC.js";export{t as start};
