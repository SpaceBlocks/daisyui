import{L as e,_ as n}from"../chunks/0.d77FagKz.js";export{e as component,n as universal};
