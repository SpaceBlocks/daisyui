import{L as e,_ as n}from"../chunks/0.cni45Z9Q.js";export{e as component,n as universal};
